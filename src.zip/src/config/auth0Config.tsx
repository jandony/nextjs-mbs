const auth0Config = {
    clientId: 'ABKHCX5nLcqKe76JxEPMXsyKWBNDy6HO',
    clientSecret:
        'wGhAPEOEhQZm5dkECdD1KQFr86LDvvMK2IppqKoKlln4BQqcd8R8CxqKRImjDzS7',
    scope: 'openid profile email',
    domain: 'dev-y8kw4lsqfwvzoc2k.us.auth0.com',
    redirectUri: 'http://localhost:3000//api/auth/callback',
}

export default auth0Config
