import Inbox from './inbox';

function Email() {
  return (
    <>
      <Inbox />
    </>
  );
}

export default Email;
