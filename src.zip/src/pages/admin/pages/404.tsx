import NotFound from "@/pages/404";

function ErrorPage() {
  return (
    <NotFound />
  )
}

export default ErrorPage;
