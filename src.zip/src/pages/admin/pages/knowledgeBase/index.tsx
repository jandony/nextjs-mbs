import ArticlePlugin from './plugins';

function KnowledgeBase () {

  return (
    <>
      <ArticlePlugin />        
    </>
  );
}

export default KnowledgeBase;
