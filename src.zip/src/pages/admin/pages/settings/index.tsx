import Profile from './profile';

const Settings = () => {
  return (
    <Profile/>
  );
};

export default Settings;
