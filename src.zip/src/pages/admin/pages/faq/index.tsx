import Applications from './applications';

const Settings = () => {
  return (
    <Applications />
  );
};

export default Settings;
