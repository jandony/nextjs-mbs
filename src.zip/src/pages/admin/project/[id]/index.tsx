import TaskList from './tasklist';

function ProjectDetails() {
  return (
    <TaskList />
  );
}

export default ProjectDetails;
