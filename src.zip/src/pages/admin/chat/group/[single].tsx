import React from 'react';
import ChatLayout from '../Layout';

function GroupChatDetails() {
  return (
    <ChatLayout />
  );
}

export default GroupChatDetails;
