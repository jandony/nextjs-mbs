import ChatLayout from './Layout';

function ChatApp() {
  return (
    <ChatLayout />
  );
}

export default ChatApp;
