import React from 'react';
import ChatLayout from '../Layout';

function PrivateChatDetails() {
  return (
    <ChatLayout />
  );
}

export default PrivateChatDetails;
