import React from 'react';
import ChatLayout from '../Layout';

function AllContactDetails() {
  return (
    <ChatLayout />
  );
}

export default AllContactDetails;
